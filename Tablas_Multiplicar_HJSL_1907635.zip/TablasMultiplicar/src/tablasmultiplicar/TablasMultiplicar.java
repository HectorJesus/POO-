package tablasmultiplicar;

/**
 *
 * @author hecto
 */
import java.util.Scanner;

public class TablasMultiplicar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner tablas = new Scanner(System.in);
        
        int a,b,c,d, filas, columnas, bandera2;
        int count = 0, resultado = 0;
            
        /*Se declara la variable cld para poder mandar a llamar a la funcion Calculadora()*/  
        Calculadora cld = new Calculadora();
        
        System.out.println("Tabla Inicial:");
        a = tablas.nextInt();
        System.out.println("Tabla Final:");
        b = tablas.nextInt();
        System.out.println("Valor Inicial:");
        c = tablas.nextInt();
        System.out.println("Valor Final:");
        d = tablas.nextInt();
        
        filas = b - a;
        columnas = d - c;
        bandera2 = c;
        
        /*Se manda a llamar a la funcion Calculadora con todos sus parametros*/
        cld.calcular(d, columnas, filas, bandera2, a);
        
    }
    
}
