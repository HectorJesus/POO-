/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tablasmultiplicar;

/**
 *
 * @author hecto
 */
public class Calculadora {
    
    public void calcular(int s, int columnas, int filas, int bandera2, int a)
    {
        int resultado;
        int bandera1;
        for (int x = 1; x <= columnas+1 ; x++) {
            bandera1 = a;
            for (int j = 1; j <= filas+1 ; j++) {
                resultado = (bandera1)*(bandera2);
                System.out.print(bandera1 + "x" + bandera2 + " = " + resultado + "    ");
                bandera1++;
            }
            System.out.print("\n");
            bandera2++;
            
        }

    }
    
}
