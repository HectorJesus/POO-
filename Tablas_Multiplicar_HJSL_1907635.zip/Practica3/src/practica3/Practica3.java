
package practica3;

/**
 *
 * @author hecto
 */

import java.util.Scanner;

public class Practica3 {

    
    public static void main(String[] args) {
        
        Scanner op = new Scanner(System.in);
        Scanner num = new Scanner(System.in); 
        String conj = "";
        int i = 0;
        int decision;
        float num_one, num_two, resultado;
        
        do{
            num_one = 0;
            num_two = 0;
            resultado = 0;
            
                        //<----------------  Menu  ---------------->
            System.out.println("<--------Bienvenido-------->\n");
            System.out.println("\t1. Suma\n\t2. Resta\n\t3. Multiplicacion\n\t4. Division\n\t5. Salir\n");
            System.out.println("<-------------------------->\nR= ");
            
             decision = op.nextInt();
            
            if(decision == 5){
                return;
            }else
            
            System.out.println("Primer Digito : ");
            
            num_one = num.nextFloat();
            
            System.out.println("Segundo Digito : ");
            
            num_two = num.nextFloat();
            
            switch(decision){
                case 1 : resultado = num_one + num_two;
                         conj = "suma";
                        break;
                case 2 : resultado = num_one - num_two;
                         conj = "resta";
                        break;
                case 3 : resultado = num_one * num_two;
                         conj = "multiplicacion";
                        break;
                case 4 : resultado = num_one / num_two;
                         conj = "division";
                        break;                
                default : System.out.println("\n\tIngrese una opcion correcta\n");
                        break;
            }
            
            System.out.println("El resultado de la " + conj + " es de " + resultado);
            
        }while(i == 0);
        
    }
    
}
