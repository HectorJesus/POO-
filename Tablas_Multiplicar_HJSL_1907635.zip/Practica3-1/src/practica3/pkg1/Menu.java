/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3.pkg1;

/**
 *
 * @author hecto
 */
public class Menu {
    
    public void menu(int decision, float num_one, float num_two){
        
        float resultado = 0;
        String conj = "";
        
        switch(decision){
                
            case 1 : resultado = num_one + num_two;
                         conj = "suma";
                        break;
                case 2 : resultado = num_one - num_two;
                         conj = "resta";
                        break;
                case 3 : resultado = num_one * num_two;
                         conj = "multiplicacion";
                        break;
                case 4 : resultado = num_one / num_two;
                         conj = "division";
                        break;                
                default : System.out.println("\n\tIngrese una opcion correcta\n");
                        break;
                        
            }
        
         System.out.println("El resultado de la " + conj + " es de " + resultado);
        
    }
    
}
