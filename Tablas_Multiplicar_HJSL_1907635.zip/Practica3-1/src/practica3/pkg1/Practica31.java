
package practica3.pkg1;

/**
 *
 * @author hecto
 */
 import java.util.Scanner;

public class Practica31 {


    public static void main(String[] args) {
        
        Scanner glob = new Scanner(System.in);
        
        int i = 0;
        int decision;
        float num_one, num_two;
        
        Menu menu_1 = new Menu();
        
        do{
                        //<----------------  Menu  ---------------->
            System.out.println("<--------Bienvenido-------->\n");
            System.out.println("\t1. Suma\n\t2. Resta\n\t3. Multiplicacion\n\t4. Division\n\t5. Salir\n");
            System.out.println("<-------------------------->\nR= ");
            
            decision = glob.nextInt();
            
            if(decision == 5){
                return;
            }else
            
            System.out.println("Primer Digito : ");
            
            num_one = glob.nextFloat();
            
            System.out.println("Segundo Digito : ");
            
            num_two = glob.nextFloat();
            
            menu_1.menu(decision, num_one, num_two);
            
        }while(i == 0);
            
            
    }
    
}
